# -*- coding: utf-8 -*-
"""
Created on Sun Oct 28 14:26:09 2018

@author: shane
"""

import sys
import os
from nbs_api import API
import numpy as np
import csv
import json
import datetime
from datetime import datetime
from datetime import timedelta

# Open artist data file
#artistFile = open(sys.argv[1])
artistFile = open("artist100.csv")
artistReader = csv.reader(artistFile, delimiter=',',)

# Count rows in file, initialize data structure
artistCount = sum(1 for row in artistReader) - 1
summary  = []
followers = []
mentions = []
artistFile.seek(0)

# Get artist names from second column in file
i = -1
api = API("martial")
for row in artistReader:
    if i != -1:
        # Get chart date, tracking start and end dates, artist name
        chartDate = datetime.strptime(row[0], '%Y-%m-%d')
        trackingDays = 7
        startDate = chartDate + timedelta(days=-trackingDays)
        endDate = chartDate + timedelta(days=-1)
        name = str(row[1])
        
        # Get artist info
        artistInfo = json.loads(api.artistSearch(name.replace("_",",")))
        nbsId = list(artistInfo.keys())[0]
        
        # Get social media data
        socialMediaData = json.loads(api.metricsArtist(nbsId, opt=[startDate,endDate,None]))

        # Get Twitter data
        hasTwitter = False
        for platform in list(socialMediaData):
            if platform['Service']['name'] == 'Twitter':              
                # Check if the Twitter data is populated
                if type(platform['Metric']['fans']) is list:
                    break
                else:
                    hasTwitter = True
                    
                # Grab data from API response
                for k in list(platform['Metric']['fans'].keys()):
                    followers.append([name, int(nbsId), datetime(year=1970,month=1,day=1) + timedelta(days=int(k)), platform['Metric']['fans'][k]])
                for k in list(platform['Metric']['mentions'].keys()):
                    mentions.append([name, int(nbsId), datetime(year=1970,month=1,day=1) + timedelta(days=int(k)), platform['Metric']['mentions'][k]])
                
                # Get summary data
                followerNumbers = [int(row[3]) for row in followers]
                mentionNumbers = [int(row[3]) for row in mentions]
                
                followersGained = followerNumbers[trackingDays-1] - followerNumbers[0]
                totalMentions = sum(mentionNumbers)
                avgMentions = float(totalMentions)/trackingDays
        
        if (hasTwitter == True):
            summary.append([name, int(nbsId), chartDate, followersGained, totalMentions, avgMentions])
        else:
            summary.append([name, int(nbsId), chartDate, 0, 0, 0.0])
    i += 1

# Save summary data in CSV
if not os.path.exists('summary'):
    os.makedirs('summary')
with open('summary/summary ' + chartDate.strftime("%Y-%m-%d") + '.csv', 'w+', newline='') as summaryFile:
    summaryWriter = csv.writer(summaryFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    summaryWriter.writerow(["Name","NbsId","ChartDate","FollowersGained","TotalMentions","AvgMentions"])
    summaryWriter.writerows(summary)
    
# Save detail data in CSVs
if not os.path.exists('detail'):
    os.makedirs('detail')
with open('detail/followers ' + chartDate.strftime("%Y-%m-%d") + '.csv', 'w+', newline='') as followerFile:
    followerWriter = csv.writer(followerFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    followerWriter.writerow(["Name","NbsId","MetricDate","Followers"])
    followerWriter.writerows(followers)
with open('detail/mentions ' + chartDate.strftime("%Y-%m-%d") + '.csv', 'w+', newline='') as mentionFile:
    mentionWriter = csv.writer(mentionFile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    mentionWriter.writerow(["Name","NbsId","MetricDate","Mentions"])
    mentionWriter.writerows(mentions)