from .resource import Resource

class Services(Resource):

  def list(self):
    return self.get(self.genUrl( )[:-5], "")
